class Globals {

}

module.exports = Globals;